Two Shapefiles in a folder.
